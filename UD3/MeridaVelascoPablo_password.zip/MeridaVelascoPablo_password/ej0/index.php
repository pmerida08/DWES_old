<?php

/**
 * @author Pablo Merida
 * 
 */

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pablo Merida Velasco password generado</title>
</head>

<body>
    <form action="procesar_form.php" method="POST">
        <h2>Ejercicio 0: Calcular Password</h2>
        <label for="">Introduce tu DNI:
            <input type="text" name="dni"><br>
        </label><br>
        <button type="submit" name="submit">Enviar</button>
    </form>

</body>

</html>