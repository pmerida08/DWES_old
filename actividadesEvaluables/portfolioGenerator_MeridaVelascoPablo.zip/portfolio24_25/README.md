# Generador de Portfolios

## Descripción

Este proyecto es un generador de portfolios que permite a los usuarios crear su propio portfolio de manera sencilla y rápida. El usuario podrá añadir sus datos personales, una descripción sobre él, sus habilidades, proyectos y formación. Además, podrá añadir una foto de perfil y una foto de fondo para personalizar su portfolio.
