<?php

require_once '../config/database.php';

require_once '../autoload.php';

require_once '../routes/web.php';